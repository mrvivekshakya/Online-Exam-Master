<form action="tryquiz.php" method="POST">
<?php
include("head.php");
?>
<?php
$con=mysqli_connect("localhost","root","","exam");
if(!$con)
{
	echo "Database is not connected because: ".mysqli_connect_error();
}

$sel="SELECT * FROM TBLCPP ORDER BY 1";
$select=mysqli_query($con,$sel);
$rows=mysqli_num_rows($select);
$qs=mysqli_fetch_row($select);
if($select)
{
	for($i=0;$i<$rows;$i++)
	{
		for($j=0;$j<count($qs);$j++)
		{
			$ar[$i][$j]=$qs[$j];
			echo $ar[$i][$j]."   ";
		}
		echo "<br>";
	}
} 
else
{
	echo "something went to wrong.";
}
?>
</form>

$ar[1]