<head>
	<?php
    include("head.php");
  ?>
  <link rel="stylesheet" type="text/css" href="css/header.css">
  <link rel="icon" href="img/favicon.png">
  <style type="text/css">
    .icon-bar2 {
    width: 100%;
    padding: 0px 30px 0px 70px;
    overflow: auto;
}

.icon-bar2 a {
    float: left;
    width: 10%;
    text-align: center;
    padding: 0px 20px 0px 20px;
    transition: all 0.3s ease;
    color: #368EC8;
    font-size: 20px;
}

.icon-bar2 a:hover {
    color: #F25119;;
}
.col2{
  display: block;
}

.col111{
  text-align: left;
}
.aa11
{
  background-color: black;
  opacity: 0.9;
  border-radius: 100px;
  height: 40px;
  width: 50px;
}
@media screen and (max-width: 992px) {
  .col2{
    display: none;
  }
  .col111{
     text-align: center;
  }
}

  </style>
 
</head>
<!--
<img src="img/ipem.png" style="width: 100%;">
-->
<div class="container-fluid" style="background-color: white;">
  <div class="row">
  <div class="col-md-4" col111><img src="img/logo.png" style="margin:0px 40px 0px 40px;height: 70px;" class="img-responsive"></div>
  <div class="col-md-4 col2"></div>
  <div class="col-md-4 col2">
    <div class="icon-bar2" style="padding-top: 25px;">
      <a href="https://www.facebook.com/vivek.shakya.503645"><i class="fa fa-facebook"></i></a> 
      <a href="https://www.instagram.com/mr.vivek.shakya/"><i class="fa fa-instagram"></i></a> 
      <a href="https://www.youtube.com/channel/UCMVjkAv2_s7PZ0yGOEMc7MA"><i class="fa fa-youtube"></i></a> 
      <a href="http://someimportantpages.blogspot.com/"><i class="fa fa-globe"></i></a>
      <a href="https://www.linkedin.com/in/vivek-shakya-a516b316b/"><i class="fa fa-linkedin"></i></a> 
    </div>
  </div>
</div>
</div>

<nav class="navbar navbar-inverse" style="position: sticky;top: 0; z-index: 10;border-radius: 0px;background-color: #0C393D;">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
     
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="index.php" style="background-color: #0C393D ;">Home</a></li>
        <li><a href="aboutus.php" style="background-color: #0C393D ;">About Us</a></li>
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#" style="background-color: #0C393D ;">Quiz with Ans.<span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li class="dli"><a href="ait.php" class="da" style="padding: 12px;"><font color="gray">IT</font></a></li>
            <li class="dli"><a href="agk.php" class="da" style="padding: 12px;"><font color="gray">GK</font></a></li>
            <li class="dli"><a href="aeducation.php" class="da" style="padding: 12px;"><font color="gray">Education</font></a></li>
            <li class="dli"><a href="amanagement.php" class="da" style="padding: 12px;"><font color="gray">Management</font></a></li>
            <li class="dli"><a href="alaw.php" class="da" style="padding: 12px;"><font color="gray">Law</font></a></li>
          </ul>
        </li>
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#" style="background-color: #0C393D ;">Play Quiz<span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li class="dli"><a href="pit.php" class="da" style="padding: 12px;"><font color="gray"> Play IT Quiz</font></a></li>
            <li class="dli"><a href="pgk.php" class="da" style="padding: 12px;"><font color="gray"> Play GK Quiz</font></a></li>
            <li class="dli"><a href="peducation.php" class="da" style="padding: 12px;"><font color="gray"> Play Education Quiz</font></a></li>
            <li class="dli"><a href="pmanagement.php" class="da" style="padding: 12px;"><font color="gray"> Play Management Quiz</font></a></li>
            <li class="dli"><a href="plaw.php" class="da" style="padding: 12px;"><font color="gray"> Play Law Quiz</font></a></li>
          </ul>
        </li>
         <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#" style="background-color: #0C393D ;">Ques. Ans.<span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li class="dli"><a href="qit.php" class="da" style="padding: 12px;"><font color="gray"> IT Ques. Ans.</font></a></li>
            <li class="dli"><a href="qgk.php" class="da" style="padding: 12px;"><font color="gray"> GK Ques. Ans.</font></a></li>
            <li class="dli"><a href="qeducation.php" class="da" style="padding: 12px;"><font color="gray"> Education Ques. Ans.</font></a></li>
            <li class="dli"><a href="qmanagement.php" class="da" style="padding: 12px;"><font color="gray"> Management Ques. Ans.</font></a></li>
            <li class="dli"><a href="qlaw.php" class="da" style="padding: 12px;"><font color="gray"> Law Ques. Ans.</font></a></li>
          </ul>
        </li>
        <li><a href="news.php" style="background-color: #0C393D ;">News</a></li>
        <li><a href="contactus.php" style="background-color: #0C393D ;">Contact Us</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="signup.php"><span class="fa fa-user"></span> Sign Up</a></li>
        <li><a href="login.php"><span class="fa fa-sign-in"></span> Login</a></li>
      </ul>
    </div>
  </div>
</nav>

