<!--Start page Reloading Validation-->
<?php
session_start();
if((isset($_SESSION['as_a'])) && ($_SESSION['as_a']=="admin"))
{
}
else
{
	header("location:index.php");
}
?>
<!--End Page Reloading Validation-->


<?php include("header1.php"); ?>
<head>
	<link rel="stylesheet" type="text/css" href="css/admin_panel.css">
	<style type="text/css">
    .main
    {
        margin-top:-21px;
        z-index: 0;
    }   
        .an{
      text-decoration: none;
      color: #F25119;
    }
    .an:hover
    {
      text-decoration: none;
      color: #F25119;
      text-shadow: 1px 1px 2px white;
      background-color: #0C393D;
  }
    .buttonn
    {
        background-color: #0A585B;
        border: 0px inset #F25119;
        border-radius: 10px;
    }
    .active1
    {
        background-color: #0C393D;
    }
    .nav11
    {
        display: block;
    }
    .bars
    {
        
        font-size: 22px;
        padding: 10px;
        color: #F25119;
        display: none;
        margin-top: -66px;
        width: 30px;
        
    }
    .bars:hover{
      color: #F25119;
      text-shadow: 1px 1px 2px white;
    }
    @media screen and (max-width: 768px){
        .nav11
        {
            display: none;
            position: absolute;
            width: 400px;
            z-index: 10;
        }
        .bars
        {
            display: block;
            z-index: 10;
            position:sticky;
            top: 8;
            
        }
        .first_part{
            display: none;
            position:sticky;
            top: 8;
        }
    }

    
    </style>
    <script type="text/javascript">
        function show()
        {
            a=document.getElementById('nav11').style;
            if(a.display=="block")
            {
                a.display="none";
            }
            else
            {
                a.display="block";
            }
        }
    </script>
</head>


<div class=" bars" id="bars" onclick="show()"><span class="fa fa-bars"></span></div>
<body class="bg-success">
    <div class="container-fluid main">
        <div class="row" >
            <div class="col-md-2 first_part nav11" style="padding: 0px;background-color:#0A585B;height: 90%;" id="nav11">
                
				<div class="btn-group-vertical btn-block" >
                    <a class="an btn btn-lg btn-block buttonn" href="admin_panel.php" style="text-shadow: 2px 2px 2px white;font-weight: 1000;">Admin Panel</a>
					<a class="an btn btn-lg btn-block buttonn" href="admin_profile.php"><span class="fa fa-user"></span> &nbsp;Profile</a>
					<a class="an btn btn-lg btn-block buttonn" href="activities.php">Activities</a>
					<a class="an btn btn-lg btn-block buttonn" href="teachers_list.php">Teacher's List</a>
					<a class="an btn btn-lg btn-block buttonn" href="students_list.php">Student's List</a>
					<a class="an btn btn-lg btn-block buttonn" href="exam_it.php" >Make a IT Exam</a>
					<a class="an btn btn-lg btn-block buttonn" href="exam_gk.php">Make a GK Exam</a>
					<a class="an btn btn-lg btn-block buttonn" href="exam_ma.php">Make a Mang. Exam</a>
					<a class="an btn btn-lg btn-block buttonn" href="exam_ed.php">Make a Education Exam</a>
					<a class="an btn btn-lg btn-block buttonn" href="exam_la.php">Make a Law Exam</a>
                    <a class="an btn btn-lg btn-block buttonn" href="schedule_exam.php">Schedule a Exam</a>
                    <a class="an btn btn-lg btn-block buttonn" href="change_admin_pass.php">Change Password</a>


				</div>
			</div>
			<div class="col-md-10" style="padding: 0px;">

            <!--php start for fectching all details of this teacher-->

            <?php

            include("connection.php");
            $id = $_GET['id'];
            $user=$_GET['user'];

            $sel = "SELECT * FROM TEACHER_SIGNUP WHERE username='$user'";
            $select = mysqli_query($con,$sel);
            $teacher = mysqli_fetch_row($select);

            echo "$teacher[5]";
            ?>

            <!--php end for fectching all details of this teacher-->

				<div class="container-fluid bg-danger" style="border: 1px dashed #F25119;margin-bottom: 15px;">
        <h1 class="text-center" style="font-family: algerian;color: #0A585B;font-weight: 600;">U<span style="font-size: 25px;">pdate</span> T<span style="font-size: 25px;">eacher's</span> P<span style="font-size: 25px;">rofile</span></h1>
        <form class="form-horizontal" action="teacher_signup_action.php" method="POST"  enctype="multipart/form-data">
            <div class="form-group">
                <label  class="control-label col-md-2" for="fname">Teacher's Name: </label>
                <div class="col-md-5">
                    <input type="text" name="fname" placeholder=" First Name" class="form-control" required/>
                </div>
                <div class="col-md-5">
                    <input type="text" name="sname" placeholder=" Second Name" class="form-control" required/>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-2" for="username">Username: </label>
                <div class="col-md-4">
                    <input type="text" name="username" placeholder="Username" class="form-control" required/><span><?php
                    if(isset($_GET["u"])) echo "<font color='red'> Username is not matched.</font>"; ?></span>
                </div>
                <label class="control-label col-md-2" for="username">Email: </label>
                <div class="col-md-4">
                    <input type="email" name="email" placeholder="Email Address" class="form-control" required/>
                </div>
            </div>
            <div class="form-group">
                <label  class="control-label col-md-2" for="mobile">Mobile: </label>
                <div class="col-md-1">
                    <select name="code" class="form-control">
                        <option value="+91">+91</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <input type="number" name="mobile" placeholder="9027149894" class="form-control" required/>
                </div>
                <label  class="control-label col-md-1" for="phone">Phone: </label>
                <div class="col-md-4">
                    <input type="text" name="phone" placeholder="23 545 45" class="form-control" required/>
                </div> 
            </div>
            <div class="form-group">
                <label class="control-label col-md-2" for="username">Address: </label>
                <div class="col-md-10">
                    <input type="text" name="add1" placeholder="Address Line 1" class="form-control" required/>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-2" for=""></label>
                <div class="col-md-10">
                    <input type="text" name="add2" placeholder="Address Line 2" class="form-control" required/>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-2" for="city">City: </label>
                <div class="col-md-4">
                    <input type="text" name="city" placeholder="City" class="form-control" required/>
                </div>
                <label class="control-label col-md-2" for="state">State: </label>
                <div class="col-md-4">
                    <input type="text" name="state" placeholder="State" class="form-control" required/>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-2" for="portal">Zip Code/Portal: </label>
                <div class="col-md-4">
                    <input type="number" name="portal" placeholder="205001" class="form-control" required/>
                </div>
                <label class="control-label col-md-2" for="country">Country: </label>
                <div class="col-md-4">
                    <input type="text" name="country" placeholder="Country" class="form-control" required/>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-2" for="DOB">Date of Birth: </label>
                <div class="col-md-4">
                    <input type="date" name="dob" min="01-01-1990"  class="form-control" required/>
                </div>
                <label class="control-label col-md-2" for="gender">Gender: </label>
                <div class="col-md-4">
                    <label class="radio-inline">
                        <input type="radio" name="gender" value="male" required/>Male
                    </label>
                    <label class="radio-inline">
                        <input type="radio" name="gender" value="female" required/>Female
                    </label>
                    <label class="radio-inline">
                        <input type="radio" name="gender" value="other" required/>Other
                    </label>
                </div>
            </div>
            <hr style="border:1px dashed #FFC78C;">
            <div class="form-group">
                <label class="control-label col-md-2" for="department">Department: </label>
                <div class="col-md-4">
                    <select class="form-control" name="department">
                        <option value="">--Select--</option>
                        <option value="it">IT</option>
                        <option value="management">Management</option>
                        <option value="low">Low</option>
                        <option value="education">Education</option>
                    </select>
                </div>
                <label class="control-label col-md-2" for="experience">Experience: </label>
                <div class="col-md-4">
                    <input type="number" name="experience" placeholder="2" class="form-control" required/>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-2">Qualification: </label>
                <div class="col-md-10">
                    <input type="text" name="qualification" placeholder="Qualification" class="form-control" required/>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-2" for="image">Image: </label>
                <div class="col-md-3">
                    <input type="file" name="image" required/>
                </div>
                <label class="control-label col-md-3" for="Marksheet">Higher Qualification Marksheet: </label>
                <div class="col-md-4">
                    <input type="file" name="marksheet" required/>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-2">You are: </label>
                <div class="col-md-4">
                    <select class="form-control" name="you_are">
                        <option value="">--Select--</option>
                        <option value="primary school teacher">Primary School Teacher</option>
                        <option value="junior school teacher">Junior School Teacher</option>
                        <option value="senior school teacher">Senior School Teacher</option>
                        <option value="assistant professor">Assistant Professor</option>
                        <option value="professor">Professor</option>
                    </select>
                </div>
                <label class="control-label col-md-2">Specification: </label>
                <div class="col-md-4">
                    <input type="text" name="specification" placeholder="Specification" class="form-control" required/>
                </div>
            </div>
            <div class="form-group">
                <div style="margin-left: 5px;margin-right: 15px;"><label>What interests you about Sorority Registration? </label></div>
                <textarea placeholder="Enter something here..." style="margin-left: 15px;width: 97%;height: 20%;margin-right: 15px;" name="des"></textarea>
            </div>
            <div class="form-group text-center">
                <input type="submit" name="btn" value="Submit" class="btn btn-primary btn-lg">
                <input type="reset" name="reset" value="Clear" class="btn btn-warning btn-lg">
                <input type="submit" name="print" value="Print" class="btn btn-danger btn-lg" onclick="print()">
            </div>
        </form>
    </div>
			</div>

		</div>
	</div>
</body>

<?php include("footer.php"); ?>

