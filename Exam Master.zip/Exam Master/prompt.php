<script type="text/javascript">
function MyReason(){
    var reason = prompt("Reason");
    document.getElementById("reason").value = reason;
    document.getElementById("form").submit();
}
</script>

<form id="form" method="POST" action="prompt.php">
    <input type="hidden" id="reason" name="hii"/>
</form>
<button onclick="MyReason()">Click on me</button>

<?php

$t=$_POST['hii'];
echo "$t";
?>