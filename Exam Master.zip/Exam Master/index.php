<?php
session_start();
if(isset($_SESSION["username"]))
{
	include("header1.php");
}
else
{
	include("header.php");
}
?>


<?php
include("footer.php");
?>