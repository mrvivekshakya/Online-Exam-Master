<!--Start page Reloading Validation-->
<?php
session_start();
if((isset($_SESSION['as_a'])) && ($_SESSION['as_a']=="student"))
{
}
else
{
	header("location:index.php");
}
?>
<!--End page Reloading Validation-->


<head>
	<?php include("header1.php"); ?>
</head>

<h1>This is student's panel</h1>
<button><a href="logout.php">logout</a></button>

<?php include("footer.php"); ?>