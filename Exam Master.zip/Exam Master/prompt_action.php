<?php
$t=$_POST['hii'];
echo "$t";
?>