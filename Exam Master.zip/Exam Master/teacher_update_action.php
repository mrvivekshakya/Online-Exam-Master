<?php
include("connection.php");

if((isset($_POST["btn"])) || (isset($_POST["btnm"])))
{
	$id=$_POST['id'];
	$email=$_POST['email'];
	$username=$_POST["username"];
	$cpass=$_POST['cpass'];
	$pass=$_POST['pass'];
	$rpass=$_POST['rpass'];
	//for button
	$btn=$_POST['btn'];

	//factch username
    $sel="SELECT * FROM SIGNUP ORDER BY 1";
    $select=mysqli_query($con,$sel);
    $rows=mysqli_num_rows($select);
    $flag=1;

    while($rows!=0)
    {
    	while($data=mysqli_fetch_assoc($select))
    	{
    		if($username==$data['username'])
    		{
    			$flag=0;
    		}
        $rows--;
        }
    }

    if($flag==1)
    {
    	$sel = "SELECT * FROM SIGNUP WHERE id='$id'";
    $select = mysqli_query($con,$sel);
    $teacher = mysqli_fetch_row($select);

    if(($cpass==$teacher[3]) && ($pass==$rpass))
    {
    	$up="UPDATE SIGNUP SET email='$email', username='$username', pass='$pass' WHERE id='$id'";
    	$update=mysqli_query($con,$up);
    	if($update)
    	{
    		if($btn=="update")
    		{
    			header("location:teachers_list.php?t=0");
    		}
    		else if($btn=="update_more")
    		{
    			header("location:teacher_update_detail.php?username=$username");
    		}
    		else
    		{
    			echo "<script> alert('Something went to wrong.'); </script>";
    		}
    	}
    	else
    	{
    		header("location:teacher_update.php?id1=$id&username=$username&email=$email");
    	}
    }        
    else
    {
    	header("location:teacher_update.php?id1=$id&username=$username&email=$email&cur=0");
    }
    }
    else if($flag==0)
    {
    	header("location:teacher_update.php?already=0&id1=$id&username=$username&email=$email");
    }
    else
    {
    	echo "<script> alert('Something Went to Wrong.'); </scrript>";
    }
}
else
{
	echo "Something went to wrong.";
}
?>