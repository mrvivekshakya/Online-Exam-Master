<!--Start page Reloading Validation-->
<?php
session_start();
if((isset($_SESSION['as_a'])) && ($_SESSION['as_a']=="admin"))
{
}
else
{
	header("location:index.php");
}
?>
<!--End Page Reloading Validation-->


<?php include("header1.php"); ?>
<head>
	<link rel="stylesheet" type="text/css" href="css/admin_panel.css">
	<style type="text/css">
    .main
    {
        margin-top:-21px;
        z-index: 0;
    }   
        .an{
      text-decoration: none;
      color: #F25119;
    }
    .an:hover
    {
      text-decoration: none;
      color: #F25119;
      text-shadow: 1px 1px 2px white;
      background-color: #0C393D;
  }
    .buttonn
    {
        background-color: #0A585B;
        border: 0px inset #F25119;
        border-radius: 10px;
    }
    .active1
    {
        background-color: #0C393D;
    }
    .nav11
    {
        display: block;
    }
    .bars
    {
        
        font-size: 22px;
        padding: 10px;
        color: #F25119;
        display: none;
        margin-top: -66px;
        width: 30px;
        
    }
    .bars:hover{
      color: #F25119;
      text-shadow: 1px 1px 2px white;
    }
    @media screen and (max-width: 768px){
        .nav11
        {
            display: none;
            position: absolute;
            width: 400px;
            z-index: 10;
        }
        .bars
        {
            display: block;
            z-index: 10;
            position:sticky;
            top: 8;
            
        }
        .first_part{
            display: none;
            position:sticky;
            top: 8;
        }
    }

    
    </style>
    <script type="text/javascript">
        function show()
        {
            a=document.getElementById('nav11').style;
            if(a.display=="block")
            {
                a.display="none";
            }
            else
            {
                a.display="block";
            }
        }
    </script>
</head>


<div class=" bars" id="bars" onclick="show()"><span class="fa fa-bars"></span></div>
<body class="bg-success">
    <div class="container-fluid main">
        <div class="row" >
            <div class="col-md-2 first_part nav11" style="padding: 0px;background-color:#0A585B;height: 90%;" id="nav11">
                
				<div class="btn-group-vertical btn-block" >
                    <a class="an btn btn-lg btn-block buttonn" href="admin_panel.php" style="text-shadow: 2px 2px 2px white;font-weight: 1000;">Admin Panel</a>
					<a class="an btn btn-lg btn-block buttonn" href="admin_profile.php"><span class="fa fa-user"></span> &nbsp;Profile</a>
					<a class="an btn btn-lg btn-block buttonn" href="activities.php">Activities</a>
					<a class="an btn btn-lg btn-block buttonn" href="teachers_list.php">Teacher's List</a>
					<a class="an btn btn-lg btn-block buttonn" href="students_list.php">Student's List</a>
					<a class="an btn btn-lg btn-block buttonn" href="exam_it.php" >Make a IT Exam</a>
					<a class="an btn btn-lg btn-block buttonn" href="exam_gk.php">Make a GK Exam</a>
					<a class="an btn btn-lg btn-block buttonn" href="exam_ma.php">Make a Mang. Exam</a>
					<a class="an btn btn-lg btn-block buttonn" href="exam_ed.php">Make a Education Exam</a>
					<a class="an btn btn-lg btn-block buttonn" href="exam_la.php">Make a Law Exam</a>
                    <a class="an btn btn-lg btn-block buttonn" href="schedule_exam.php">Schedule a Exam</a>
                    <a class="an btn btn-lg btn-block buttonn" href="change_admin_pass.php">Change Password</a>


				</div>
			</div>
			<div class="col-sm-10" style="padding: 0px;">
				<?php
                    include("connection.php");
                    $sel = "SELECT * FROM SIGNUP WHERE as_a='student'";
                    $select = mysqli_query($con,$sel);
                    $rows = mysqli_num_rows($select);
                    if($rows==0)
                    {
                    	echo "<table class='table table-responsive table-bordered table-hover bg-success'><tr><th colspan='5'><h1 class='text-center'>There is Student Listed.</h1></th></tr></table>";
                    }
                    else
                    {
                    	echo "<table class='table table-responsive table-bordered table-hover'><tr><th colspan='7'><h1 class='text-center' style='font-family:algerian;color:#0A585B;font-weight:600;'>Student's List</h1></th></tr><tr><th>Teacher's ID</th><th>Username</th><th>Email</th><th>Password</th><th>D.O.J.</th><th colspan='2' class='text-center'>Action</th></tr>";
                    	while($rows!=0)
                        {
                    	    $teacher = mysqli_fetch_row($select);
                    	    echo "<tr><td>$teacher[0]</td><td>$teacher[1]</td><td>$teacher[2]</td><td>$teacher[3]</td><td>$teacher[4]</td><td><a href='student_update.php'>Update</a></td><td><a href='student_delete.php'>Delete</a></td></tr>";
                    	    $rows--;
                        }
                        echo "</table>";
                    }

				?>
			</div>

		</div>
	</div>
</body>

<?php include("footer.php"); ?>

