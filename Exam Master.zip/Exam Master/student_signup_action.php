<?php
include("connection.php");
if(isset($_POST["btn"]))
{
    $fname = $_POST["fname"];
    $sname = $_POST["sname"];
    $username = $_POST["username"];
    $email = $_POST["email"];
    $code = $_POST["code"];
    $mobile = $_POST["mobile"];
    $phone = $_POST["phone"];
    $add1 = $_POST["add1"];
    $add2 = $_POST["add2"];
    $city = $_POST["city"];
    $state = $_POST["state"];
    $portal = $_POST["portal"];
    $country = $_POST["country"];
    $dob = $_POST["dob"];
    $gender = $_POST["gender"];
    $status = $_POST["status"];
    $university = $_POST["university"];
    
    //for image
    $image = $_FILES["image"]["tmp_name"];
    $rimage = $_FILES["image"]["name"];
    $folder= "uploads/students/".$rimage;

    $des = $_POST["des"];

    //fatch existing username
    $sel="SELECT * FROM SIGNUP ORDER BY 1";
    $select=mysqli_query($con,$sel);
    $rows=mysqli_num_rows($select);
    $flag=0;
    while($rows!=0)
    {
        while($data=mysqli_fetch_assoc($select))
        {
            if($username==$data['username'])
            {
                $flag=1;
            }
        }
        $rows--;
    }
    if($flag==1)
    {
        $ins = "INSERT INTO STUDENT_SIGNUP(fname,sname,username,email,code,mobile,phone,address1,address2,city,state,portal,country,dob,gender,status,university,image,description) values('$fname','$sname','$username','$email','$code','$mobile','$phone','$add1','$add2','$city','$state','$portal','$country','$dob','$gender','$status','$university','$rimage','$des')";
        $insert = mysqli_query($con,$ins);
        if($insert)
        {
            move_uploaded_file($image, $folder);
            header("location:login.php");
        }
        else
        {
                    echo "Something went to wrong"; 
        }
    }
    if($flag==0)
    {
        header("location:student_signup.php?u=0");
    }
}
?>