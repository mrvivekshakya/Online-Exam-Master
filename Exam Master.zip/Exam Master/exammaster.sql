-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 04, 2020 at 09:06 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `exammaster`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `sname` varchar(50) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `code` varchar(10) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `address1` varchar(200) NOT NULL,
  `address2` varchar(200) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `portal` varchar(10) NOT NULL,
  `country` varchar(20) NOT NULL,
  `dob` varchar(50) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `department` varchar(50) NOT NULL,
  `experience` varchar(40) NOT NULL,
  `qualification` varchar(200) NOT NULL,
  `image` varchar(100) NOT NULL,
  `marksheet` varchar(100) NOT NULL,
  `you_are` varchar(50) NOT NULL,
  `specification` varchar(50) NOT NULL,
  `description` varchar(500) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `exams`
--

CREATE TABLE `exams` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `inform` varchar(50) NOT NULL,
  `permission` varchar(50) NOT NULL,
  `code` varchar(10) NOT NULL,
  `verified` int(10) NOT NULL,
  `tyme` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `depart` varchar(50) NOT NULL,
  `created_by` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exams`
--

INSERT INTO `exams` (`id`, `name`, `type`, `inform`, `permission`, `code`, `verified`, `tyme`, `date`, `depart`, `created_by`) VALUES
(58, 'First', 'quiz', 'toall', 'private', '3704', 0, '30', '2019-12-09 15:10:39', 'it', 'masterji');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `as_a` varchar(50) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`, `as_a`, `date_time`) VALUES
(37, 'vivek', 'nothing@1432', 'teacher', '2019-12-09 07:28:01'),
(38, 'masterji', 'nothing@1432', 'admin', '2019-12-09 07:29:03'),
(39, 'masterji', 'nothing@1432', 'admin', '2019-12-09 12:18:29'),
(40, 'masterji', 'nothing@1432', 'admin', '2019-12-09 14:57:27'),
(41, 'akshuaggarval', 'akash1234', 'teacher', '2019-12-09 15:05:28'),
(42, 'masterji', 'nothing@1432', 'admin', '2019-12-09 15:05:59'),
(43, 'masterji', 'nothing@1432', 'admin', '2019-12-12 14:46:05'),
(44, 'masterji', 'nothing@1432', 'admin', '2019-12-13 11:17:25'),
(45, 'masterji', 'nothing@1432', 'admin', '2019-12-14 10:04:47'),
(46, 'masterji', 'nothing@1432', 'admin', '2019-12-15 08:02:23'),
(47, 'masterji', 'nothing@1432', 'admin', '2019-12-24 09:34:36');

-- --------------------------------------------------------

--
-- Table structure for table `pr_it_quiz_first`
--

CREATE TABLE `pr_it_quiz_first` (
  `qno` int(6) UNSIGNED NOT NULL,
  `question` varchar(400) NOT NULL,
  `op1` varchar(100) NOT NULL,
  `op2` varchar(100) NOT NULL,
  `op3` varchar(100) NOT NULL,
  `op4` varchar(100) NOT NULL,
  `ans` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pr_it_quiz_first`
--

INSERT INTO `pr_it_quiz_first` (`qno`, `question`, `op1`, `op2`, `op3`, `op4`, `ans`) VALUES
(1, 'This is my First Question', 'option1', 'option2', 'option3', 'option4', '3'),
(2, 'que2', 'option1', 'option2', 'option3', 'option4', '2');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `as_a` varchar(30) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`id`, `username`, `email`, `pass`, `as_a`, `date_time`) VALUES
(3, 'Shakyaji', 'shakya727@gmail.com', 'nothing@1432', 'teacher', '2019-12-09 07:23:05'),
(4, 'masterji', 'msvivekshakya727@gmail.com', 'nothing@1432', 'admin', '2019-12-09 07:27:36'),
(5, 'akshuaggarval', 'akshuaggarval25@gmail.com', 'akash1111', 'teacher', '2019-12-09 15:01:30'),
(6, 'sanjana727', 'mssanjanashakya727@gmail.com', 'sanjana@1432', 'student', '2019-12-14 09:48:20');

-- --------------------------------------------------------

--
-- Table structure for table `student_signup`
--

CREATE TABLE `student_signup` (
  `id` int(11) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `sname` varchar(50) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `code` varchar(4) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `address1` varchar(200) NOT NULL,
  `address2` varchar(100) NOT NULL,
  `city` varchar(30) NOT NULL,
  `state` varchar(30) NOT NULL,
  `portal` varchar(20) NOT NULL,
  `country` varchar(30) NOT NULL,
  `dob` varchar(30) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `status` varchar(50) NOT NULL,
  `university` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `description` varchar(500) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_signup`
--

INSERT INTO `student_signup` (`id`, `fname`, `sname`, `username`, `email`, `code`, `mobile`, `phone`, `address1`, `address2`, `city`, `state`, `portal`, `country`, `dob`, `gender`, `status`, `university`, `image`, `description`, `date_time`) VALUES
(1, 'Sanjana', 'Shakya', 'sanjana727', 'mssanjanashakya727@gmail.com', '+91', '2029289', '5354', 'Bhatiya Mod', 'Ghaziabad (U.P.)', 'Ghaziabad', 'Uttar Pradesh', '205001', 'India', '1999-12-23', 'female', 'senior', 'AKTU', 'refresh.jpg', 'This is Only for testing purpose.', '2019-12-14 09:50:14');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_signup`
--

CREATE TABLE `teacher_signup` (
  `id` int(11) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `sname` varchar(50) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `code` varchar(10) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `address1` varchar(200) NOT NULL,
  `address2` varchar(200) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `portal` varchar(10) NOT NULL,
  `country` varchar(20) NOT NULL,
  `dob` varchar(50) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `department` varchar(50) NOT NULL,
  `experience` varchar(40) NOT NULL,
  `qualification` varchar(200) NOT NULL,
  `image` varchar(100) NOT NULL,
  `marksheet` varchar(100) NOT NULL,
  `you_are` varchar(50) NOT NULL,
  `specification` varchar(50) NOT NULL,
  `description` varchar(500) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher_signup`
--

INSERT INTO `teacher_signup` (`id`, `fname`, `sname`, `username`, `email`, `code`, `mobile`, `phone`, `address1`, `address2`, `city`, `state`, `portal`, `country`, `dob`, `gender`, `department`, `experience`, `qualification`, `image`, `marksheet`, `you_are`, `specification`, `description`, `date_time`) VALUES
(2, 'Vivek', 'Shakya', 'vivek', 'mrvivekshakya727@gmail.com', '+91', '9027149894', '124233', 'Vill. & Post Angautha Mainpuri', 'UP', 'Mainpuri', 'Uttar Pradesh', '205001', 'India', '2001-02-15', 'male', 'it', '2', 'MCA', 'A-04.jpg', 'img20170909_20132928-1.jpg', 'assistant professor', 'PHP', 'This is a teacher', '2019-12-09 07:25:58'),
(3, 'Akash', 'Aggarwal', 'akshuaggarval', 'akshuaggarval25@gmail.com', '+91', '8802627170', '2029289', 'Bhatiya Mod', 'Ghaziabad (U.P.)', 'Ghaziabad', 'Uttar Pradesh', '205001', 'India', '1999-07-25', 'male', 'it', '2', 'MCA', 'A-04.jpg', 'img726.jpg', 'assistant professor', 'Java', 'There was not a problem.', '2019-12-09 15:05:11');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exams`
--
ALTER TABLE `exams`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pr_it_quiz_first`
--
ALTER TABLE `pr_it_quiz_first`
  ADD PRIMARY KEY (`qno`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_signup`
--
ALTER TABLE `student_signup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teacher_signup`
--
ALTER TABLE `teacher_signup`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `exams`
--
ALTER TABLE `exams`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;
--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;
--
-- AUTO_INCREMENT for table `pr_it_quiz_first`
--
ALTER TABLE `pr_it_quiz_first`
  MODIFY `qno` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `student_signup`
--
ALTER TABLE `student_signup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `teacher_signup`
--
ALTER TABLE `teacher_signup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
