<head>
	<link rel="stylesheet" type="text/css" href="css/footer.css">
	<style>

.icon-bar1 {
    width: 100%;
    padding: 0px 30px 0px 70px;
    overflow: auto;
}

.icon-bar1 a {
    float: left;
    width: 10%;
    text-align: center;
    padding: 0px 0;
    transition: all 0.3s ease;
    color: white;
    font-size: 18px;
}

.icon-bar1 a:hover {
    color:#F25119;
}


</style>
</head>
<div class="container-fluid">

<div class="row row11">
	<div class="col-md-3"><h3 class="h31">About Us</h3><h5 class="h51">The <a href="index.php" style="text-decoration:none;color: aqua;">www.exammaster.com</a> provides the quiz, exam and also provide the free certificate of some courses.</h5></div>
	<div class="col-md-3"><h3 class="h31">Explore</h3>
		<div class="in_div"><a href="index.php" class="in_a1">&gt;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Home</a></div>
		<div class="in_div"><a href="aboutus.php" class="in_a1">&gt;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;About Us</a></div>
		<div class="in_div"><a href="news.php" class="in_a1">&gt;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;News</a></div>
		<div class="in_div"><a href="contactus.php" class="in_a1">&gt;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Contact Us</a></div>
		<div class="in_div"><a href="signup.php" class="in_a1">&gt;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Sign Up</b></a></div>
		<div class="in_div"><a href="login.php" class="in_a1">&gt;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Login</b></a></div>
    </div>
	<div class="col-md-3"><h3 class="h31">Contact Us</h3>
		<div style="color: white;">&gt;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Phone: </b>+91 9027149894 | 8979863659</div>
		<div style="color: white;">&gt;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Address: </b>Viil. $ Post- Angautha,<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Mainpuri [U.P.]</div>
		<div style="color: white;">&gt;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Email: </b>mrvivekshakya727@gmail.com |<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;mrvk727@gmail.com</div>
	</div>
	<div class="col-md-3"><h3 class="h31">Gallery</h3>
		<div class="row">
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 pp"><a href="img/1.jpg"><img src="img/1.jpg" style="height: 70px;width: 105;" class="img-responsive"></a></div>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 pp"><a href="img/1.jpg"><img src="img/1.jpg"style="height: 70px;width: 105;" class="img-responsive"></a></div>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 pp"><a href="img/1.jpg"><img src="img/1.jpg" style="height: 70px;width: 105;" class="img-responsive"></a></div>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 pp"><a href="img/1.jpg"><img src="img/1.jpg" style="height: 70px;width: 105;" class="img-responsive"></a></div>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 pp"><a href="img/1.jpg"><img src="img/1.jpg" style="height: 70px;width: 105;" class="img-responsive"></a></div>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 pp"><a href="img/1.jpg"><img src="img/1.jpg"style="height: 70px;width: 105;" class="img-responsive"></a></div>
		</div>
	</div>
</div>
<div class="row row22" >
	<div class="col-sm-4">
		<div class="icon-bar1">
  <a href="https://www.facebook.com/vivek.shakya.503645"><i class="fa fa-facebook"></i></a> 
  <a href="https://www.instagram.com/mr.vivek.shakya/"><i class="fa fa-instagram"></i></a> 
  <a href="https://www.youtube.com/channel/UCMVjkAv2_s7PZ0yGOEMc7MA"><i class="fa fa-youtube"></i></a> 
  <a href="http://someimportantpages.blogspot.com/"><i class="fa fa-globe"></i></a>
  <a href="https://www.linkedin.com/in/vivek-shakya-a516b316b/"><i class="fa fa-linkedin"></i></a> 
</div>
	</div>
	<div class="col-sm-4" style="color: white;">Copyright &copy; 2019 www.exammaster.com  All rights reserved.</div>
	<div class="col-sm-4" style="color: white;">Designed & Developed by: <a href="https://www.linkedin.com/in/vivek-shakya-a516b316b/" class="aa">Master Vivek Shakya</a></div>
</div>
</div>