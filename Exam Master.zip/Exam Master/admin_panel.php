<!--Start page Reloading Validation-->
<?php
session_start();
if((isset($_SESSION['as_a'])) && ($_SESSION['as_a']=="admin"))
{
}
else
{
	header("location:index.php");
}
?>
<!--End Page Reloading Validation-->

<?php
include("connection.php");

//for exams
$sel = "SELECT * FROM EXAMS ORDER BY 1";
$select = mysqli_query($con,$sel);
$all_exams = mysqli_num_rows($select);

//for students
$sel = "SELECT * FROM SIGNUP WHERE as_a='teacher'";
$select = mysqli_query($con,$sel);
$all_teachers = mysqli_num_rows($select);

//for students
$sel = "SELECT * FROM SIGNUP WHERE as_a='student'";
$select = mysqli_query($con,$sel);
$all_students = mysqli_num_rows($select);

//for IT exams
$sel = "SELECT * FROM EXAMS WHERE depart='it'";
$select = mysqli_query($con,$sel);
$all_it_exams = mysqli_num_rows($select);

//for GK exams
$sel = "SELECT * FROM EXAMS WHERE depart='gk'";
$select = mysqli_query($con,$sel);
$all_gk_exams = mysqli_num_rows($select);

//for Management exams
$sel = "SELECT * FROM EXAMS WHERE depart='ma'";
$select = mysqli_query($con,$sel);
$all_ma_exams = mysqli_num_rows($select);

//for Education exams
$sel = "SELECT * FROM EXAMS WHERE depart='ed'";
$select = mysqli_query($con,$sel);
$all_ed_exams = mysqli_num_rows($select);

//for Law exams
$sel = "SELECT * FROM EXAMS WHERE depart='la'";
$select = mysqli_query($con,$sel);
$all_la_exams = mysqli_num_rows($select);
?>


<?php include("header1.php"); ?>
<head>
	<link rel="stylesheet" type="text/css" href="css/admin_panel.css">
	<style type="text/css">
	.main
	{
		margin-top:-21px;
		z-index: 0;
	}	
		.an{
      text-decoration: none;
      color: #F25119;
    }
    .an:hover
    {
      text-decoration: none;
      color: #F25119;
      text-shadow: 1px 1px 2px white;
      background-color: #0C393D;
  }
    .buttonn
    {
    	background-color: #0A585B;
    	border: 0px inset #F25119;
    	border-radius: 10px;
    }
    .active1
    {
    	background-color: #0C393D;
    }
    .nav11
    {
    	display: block;
    }
    .bars
    {
    	
    	font-size: 22px;
    	padding: 10px;
    	color: #F25119;
    	display: none;
    	margin-top: -66px;
    	width: 30px;
    	
    }
    .bars:hover{
      color: #F25119;
      text-shadow: 1px 1px 2px white;
    }
    @media screen and (max-width: 768px){
    	.nav11
    	{
    		display: none;
    		position: absolute;
    		width: 400px;
    		z-index: 10;
    	}
    	.bars
    	{
    		display: block;
    		z-index: 10;
            position:sticky;
            top: 8;
    		
    	}
        .first_part{
            display: none;
            position:sticky;
            top: 8;
        }
    }

    
	</style>
	<script type="text/javascript">
		function show()
		{
			a=document.getElementById('nav11').style;
			if(a.display=="block")
			{
				a.display="none";
			}
			else
			{
				a.display="block";
			}
		}
	</script>
</head>


<div class=" bars" id="bars" onclick="show()"><span class="fa fa-bars"></span></div>
<body class="bg-success">
	<div class="container-fluid main">
		<div class="row" >
			<div class="col-md-2 first_part nav11" style="padding: 0px;background-color:#0A585B;height: 90%;" id="nav11">
				
				<div class="btn-group-vertical btn-block " >
                    <a class="an btn btn-lg btn-block buttonn" href="admin_panel.php" style="text-shadow: 2px 2px 2px white;font-weight: 1000;">Admin Panel</a>
					<a class="an btn btn-lg btn-block buttonn" href="admin_profile.php"><span class="fa fa-user"></span> &nbsp;Profile</a>
					<a class="an btn btn-lg btn-block buttonn" href="activities.php">Activities</a>
					<a class="an btn btn-lg btn-block buttonn" href="teachers_list.php">Teacher's List</a>
					<a class="an btn btn-lg btn-block buttonn" href="students_list.php">Student's List</a>
					<a class="an btn btn-lg btn-block buttonn" href="exam_it.php">Make a IT Exam</a>
					<a class="an btn btn-lg btn-block buttonn" href="exam_gk.php">Make a GK Exam</a>
					<a class="an btn btn-lg btn-block buttonn" href="exam_ma.php">Make a Mang. Exam</a>
					<a class="an btn btn-lg btn-block buttonn" href="exam_ed.php">Make a Education Exam</a>
					<a class="an btn btn-lg btn-block buttonn" href="exam_la.php">Make a Law Exam</a>
                    <a class="an btn btn-lg btn-block buttonn" href="schedule_exam.php">Schedule a Exam</a>
                    <a class="an btn btn-lg btn-block buttonn" href="change_admin_pass.php">Change Password</a>


				</div>
			</div>
			<div class="col-md-10">
                <div class="row" style="padding: 10px;">
                    <div class="col-sm-12" style="background-color: #0A585B;border: 1px dashed #F25119;">
                        <h1 style="font-weight: 800;color: #F25119; text-align: center;text-shadow: 2px 2px 2px white;">Welcome Mr. <?php echo $_SESSION["username"]; ?></h1>
                    </div>
                </div>
                <div class="row">
                    
                    <div class="col-sm-4" style="padding: 10px;">
                        <div  style="background-color: #0A585B;padding: 10px;border-radius: 100%;box-shadow: 3px 3px 3px #F25119;">
                            <div style="text-align: center;font-size: 70px;color: #F25119;text-shadow: 2px 2px 2px white;"><span class="fa fa-users"></span></div>
                            <div style="text-align: center;font-size: 30px;color: #F25119;text-shadow:  2px 2px 2px white;font-weight: 800;"><?php echo $all_teachers-1.; echo "+"; ?></div>
                            <div style="text-align: center;font-size: 40px;color: #F25119;text-shadow:  2px 2px 2px white;font-weight: 800;">Teachers</div>
                            <div style="text-align: center;"><button class="btn btn-warning btn-lg" style="border-radius: 100%;background-color: #F25119;"><a href="teachers_list.php" style="text-decoration: none;color: white;font-weight: 1000;">All Teachers</a> </button></div>
                        </div>
                    </div>
                    <div class="col-sm-4" style="padding: 10px;">
                        <div  style="background-color: #0A585B;padding: 10px;border-radius: 100%;box-shadow: 3px 3px 3px #F25119;">
                            <div style="text-align: center;font-size: 70px;color: #F25119;text-shadow: 2px 2px 2px white;"><span class="fa fa-users"></span></div>
                            <div style="text-align: center;font-size: 30px;color: #F25119;text-shadow:  2px 2px 2px white;font-weight: 800;"><?php echo $all_students-1.; echo "+"; ?></div>
                            <div style="text-align: center;font-size: 40px;color: #F25119;text-shadow:  2px 2px 2px white;font-weight: 800;">Students</div>
                            <div style="text-align: center;"><button class="btn btn-warning btn-lg" style="border-radius: 100%;background-color: #F25119;"><a href="students_list.php" style="text-decoration: none;color: white;font-weight: 1000;">All Students</a> </button></div>
                        </div>
                    </div>
                    <div class="col-sm-4" style="padding: 10px;">
                        <div  style="background-color: #0A585B;padding: 10px;border-radius: 100%;box-shadow: 3px 3px 3px #F25119;">
                            <div style="text-align: center;font-size: 70px;color: #F25119;text-shadow: 2px 2px 2px white;"><span class="fa fa-book"></span></div>
                            <div style="text-align: center;font-size: 30px;color: #F25119;text-shadow:  2px 2px 2px white;font-weight: 800;"><?php echo $all_exams-1.; echo "+"; ?></div>
                            <div style="text-align: center;font-size: 40px;color: #F25119;text-shadow:  2px 2px 2px white;font-weight: 800;">Exams</div>
                            <div style="text-align: center;"><button class="btn btn-warning btn-lg" style="border-radius: 100%;background-color: #F25119;"><a href="#" style="text-decoration: none;color: white;font-weight: 1000;">Exam's List</a> </button></div>
                        </div>
                    </div>
                    <div class="col-sm-4" style="padding: 10px;">
                        <div  style="background-color: #0A585B;padding: 10px;border-radius: 100%;box-shadow: 3px 3px 3px #F25119;">
                            <div style="text-align: center;font-size: 70px;color: #F25119;text-shadow: 2px 2px 2px white;"><span class="fa fa-book"></span></div>
                            <div style="text-align: center;font-size: 30px;color: #F25119;text-shadow:  2px 2px 2px white;font-weight: 800;"><?php echo $all_it_exams-1.; echo "+"; ?></div>
                            <div style="text-align: center;font-size: 40px;color: #F25119;text-shadow:  2px 2px 2px white;font-weight: 800;">IT Exams</div>
                            <div style="text-align: center;"><button class="btn btn-warning btn-lg" style="border-radius: 100%;background-color: #F25119;"><a href="#" style="text-decoration: none;color: white;font-weight: 1000;">All IT Exams</a> </button></div>
                        </div>
                    </div>
                    

                   
                </div>
			</div>

		</div>
	</div>
</body>

<?php include("footer.php"); ?>