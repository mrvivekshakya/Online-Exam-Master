<!--Start page Reloading Validation-->
<?php
session_start();
if((isset($_SESSION['as_a'])) && ($_SESSION['as_a']=="admin"))
{
}
else
{
	header("location:index.php");
}
?>
<!--End Page Reloading Validation-->


<?php include("header1.php"); ?>
<head>
	<link rel="stylesheet" type="text/css" href="css/admin_panel.css">
	<style type="text/css">
	.main
	{
		margin-top:-21px;
		z-index: 0;
	}	
		.an{
      text-decoration: none;
      color: #F25119;
    }
    .an:hover
    {
      text-decoration: none;
      color: #F25119;
      text-shadow: 1px 1px 2px white;
      background-color: #0C393D;
  }
    .buttonn
    {
    	background-color: #0A585B;
    	border: 0px inset #F25119;
    	border-radius: 10px;
    }
    .active1
    {
    	background-color: #0C393D;
    }
    .nav11
    {
    	display: block;
    }
    .bars
    {
    	
    	font-size: 22px;
    	padding: 10px;
    	color: #F25119;
    	display: none;
    	margin-top: -66px;
    	width: 30px;
    	
    }
    .bars:hover{
      color: #F25119;
      text-shadow: 1px 1px 2px white;
    }
    @media screen and (max-width: 768px){
    	.nav11
    	{
    		display: none;
    		position: absolute;
    		width: 400px;
    		z-index: 10;
    	}
    	.bars
    	{
    		display: block;
    		z-index: 10;
            position:sticky;
            top: 8;
    		
    	}
        .first_part{
            display: none;
            position:sticky;
            top: 8;
        }
    }

    
	</style>
	<script type="text/javascript">
		function show()
		{
			a=document.getElementById('nav11').style;
			if(a.display=="block")
			{
				a.display="none";
			}
			else
			{
				a.display="block";
			}
		}
	</script>
</head>


<div class=" bars" id="bars" onclick="show()"><span class="fa fa-bars"></span></div>
<body class="bg-success">
	<div class="container-fluid main">
		<div class="row" >
			<div class="col-md-2 first_part nav11" style="padding: 0px;background-color:#0A585B;height: 90%;" id="nav11">
				
				<div class="btn-group-vertical btn-block">
					<a class="an btn btn-lg btn-block buttonn" href="admin_panel.php" style="text-shadow: 2px 2px 2px white;font-weight: 1000;">Admin Panel</a>
					<a class="an btn btn-lg btn-block buttonn" href="admin_profile.php"><span class="fa fa-user"></span> &nbsp;Profile</a>
					<a class="an btn btn-lg btn-block buttonn" href="activities.php">Activities</a>
					<a class="an btn btn-lg btn-block buttonn" href="teachers_list.php">Teacher's List</a>
					<a class="an btn btn-lg btn-block buttonn" href="students_list.php">Student's List</a>
					<a class="an btn btn-lg btn-block buttonn" href="exam_it.php" >Make a IT Exam</a>
					<a class="an btn btn-lg btn-block buttonn" href="exam_gk.php">Make a GK Exam</a>
					<a class="an btn btn-lg btn-block buttonn" href="exam_ma.php">Make a Mang. Exam</a>
					<a class="an btn btn-lg btn-block buttonn" href="exam_ed.php">Make a Education Exam</a>
					<a class="an btn btn-lg btn-block buttonn" href="exam_la.php">Make a Law Exam</a>
					<a class="an btn btn-lg btn-block buttonn" href="schedule_exam.php">Schedule a Exam</a>
                    <a class="an btn btn-lg btn-block buttonn" href="change_admin_pass.php">Change Password</a>

				</div>
			</div>
			<div class="col-sm-10">
				<h1 style="font-weight: 1000;color:  #0A585B;text-shadow: 2px 2px 2px #F25119;margin-bottom: 25px;">Make a Education Exam</h1>
		<form class="form-horizontal" action="exam_ed_action.php" method="POST">
			<div class="form-group">
				<label class="control-label col-md-3" for="examname" style="font-size: 20px;color: #0A585B;">Exam Name:</label>
			    <div class="col-md-9">
				    <input type="text" name="examname" placeholder="Create a Exam Name" class="form-control" style="height: 40px;font-size: 30px;background-color: #F2DEDE;" autofocus required/>
			    </div>
			</div>
			<div class="form-group">
				<label class="control-label col-md-3" for="examtype" style="font-size: 20px;color: #0A585B;">Exam Type:</label>
			    <div class="col-md-9" style="padding-top: 5px;padding-left: 30px;">
				    <div class="radio">
			    		<span style="padding-top: 20px;"><input type="radio" name="examtype" value="quiz" required/>Quiz</span>
			    	</div>
			    	<div class="radio">
			    		<span style="padding-top: 20px;"><input type="radio" name="examtype" value="true" required/>True/False Type</span>
			    	</div>
			    	<div class="radio">
			    		<span style="padding-top: 20px;"><input type="radio" name="examtype" value="onew" required/>One Word Answer Type</span>
			    	</div>
			    </div>
			</div>
			<div class="form-group">
				<label class="control-label col-md-3" for="Uploaded" style="font-size: 20px;color: #0A585B;">Permission to Show:</label>
			    <div class="col-md-9" style="padding-top: 5px;padding-left: 30px;">
				    <div class="radio">
			    		<span style="padding-top: 20px;"><input type="radio" name="for" value="public" required/>Public Only</span>
			    	</div>
			    	<div class="radio">
			    		<span style="padding-top: 20px;"><input type="radio" name="for" value="private" required/>Only for Students </span>
			    	</div>
			    	<div class="radio">
			    		<span style="padding-top: 20px;"><input type="radio" name="for" value="both" required/>For both Public and Students</span>
			    	</div>
			    </div>
			</div>
			<div class="form-group">
				<label class="control-label col-md-3" for="examtype" style="font-size: 20px;color: #0A585B;">Inform to:</label>
			    <div class="col-md-9" style="padding-top: 5px;padding-left: 30px;">
				    <div class="radio">
			    		<span style="padding-top: 20px;"><input type="radio" name="permission" value="toteacher" required/>To only teachers</span>
			    	</div>
			    	<div class="radio">
			    		<span style="padding-top: 20px;"><input type="radio" name="permission" value="tostudent" required/>To registered student</span>
			    	</div>
			    	<div class="radio">
			    		<span style="padding-top: 20px;"><input type="radio" name="permission" value="toall" required/>To all registered people</span>
			    	</div>
			    </div>
			</div>
			<div class="form-group">
				<label class="control-label col-md-3" ></label>
			    <div class="col-md-9" >
				   <input type="submit" name="" value="Next" class="btn btn-lg btn-primary" style="width:20%;background-color:#0A585B;color: #F25119; ">
			    </div>
			</div>
		</form>
			</div>

		</div>
	</div>
</body>
<?php include("footer.php"); ?>
<?php if(isset($_GET["created"])) echo "<script> alert('Your Exam is Created Successfully.');</script>"; ?>

