<?php 
include("header.php");
?>
<head>
	<link rel="stylesheet" type="text/css" href="css/signup.css">
	<script type="text/javascript">
		function validate()
		{
			p=document.getElementById("pass").value;
			rp=document.getElementById("rpass").value;
			if(p!=rp)
			{
				if(p=="")
				{
					document.getElementById("msg").innerHTML="<h5><font color='red'>Firstly Create Your Password.</font></h5>";
					return false;
				}
				else
				{
					document.getElementById("msg").innerHTML="<h5><font color='red'>Password is not matched till now.</font></h5>";
					return false;
				}
				
			}
			else
			{
				document.getElementById("msg").innerHTML="";
				return true;
			}	
		}
	</script>
</head>
<body class="bg-success">
	<div class="container">
	<div class="row">
		<div class="col-md-6"><div><img src="img/registration.png" class="imgs"></div></div>
		<div class="col-md-6 bg-danger" style="border: 1px dashed #F25119; margin: 0px 0px 20px 0px;padding: 0px;border-radius: 10px;">
			<div class="container-fluid ">
				<h1 class="hs text-center">Register Here</h1>
				<form class="form-horizontal" action="signup_action.php" method="POST" onsubmit="return validate()">
					<div class="form-group">
						<label class="control-label col-md-2">Email: </label>
						<div class="col-md-10">
							<input type="email" name="email" placeholder="Enter Your Email Address" class="form-control" autofocus required/>
						</div>
					</div><br/>
					<div class="form-group">
						<label class="control-label col-md-2">Username: </label>
						<div class="col-md-10">
							<input type="text" name="username" placeholder="Create a Username" class="form-control" autofocus required/>
							<span><?php if(isset($_GET["u"])) echo "<font color='red'>Username is already exist try another</font>";?></span>
						</div>
					</div><br/>
					<div class="form-group">
						<label class="control-label col-md-2">Password: </label>
						<div class="col-md-10">
							<input type="password" name="pass" id="pass" placeholder="Create a Password" class="form-control" autofocus required/>
						</div>
					</div><br/>
					<div class="form-group">
						<label class="control-label col-md-2" >Re-Pass: </label>
						<div class="col-md-10" >
							<input type="password" name="rpass" id="rpass" placeholder="Confirm Password" class="form-control" oninput="" autofocus required/>
						</div>
					</div><span id="msg"></span><br>
					<div class="form-group" id="as">
						<label class="control-label col-md-2">You Are: </label>
						<div class="col-md-10">
							<select class="form-control" name="as_a" id="as_a" autofocus>
							    <option value="">---Register As---</option>
							    <option value="teacher">Teacher</option>
							    <option value="student">Student</option>
							    <option value="other">Other</option>
						    </select>
						</div>
					</div>
					<div class="container-fluid">
						<button class="btn btn-primary btn-block btn-lg btns" name="btn">Register</button>
					</div><br>
					<h5>I already Signed Up.<a href="login.php" class="sup" onclick=""> Login.</a></h5>
				</form>
			</div>
		</div>
	</div>
    </div>
</body>
<?php if(isset($_GET['already'])) echo "<script> alert('This Username is already exist.\\nTry Another One.'); </script>"; ?>
<?php
include("footer.php");
?>


