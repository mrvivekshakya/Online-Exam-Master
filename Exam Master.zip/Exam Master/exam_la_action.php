<?php

include("connection.php");

$examname=$_POST["examname"];
$examtype=$_POST["examtype"];
$permission=$_POST["permission"];
$for =$_POST["for"];
$code=rand(1000,9999);
$verified = 0;
$depart = "la";
$time = "unset";
session_start();
$created_by = $_SESSION["username"];

//set as global
$_SESSION['examname']=$examname;
$_SESSION['$examtype']=$examtype;
$_SESSION['permission']=$permission;
$_SESSION['for']=$for;
$_SESSION['depart']=$depart;

//check exam name is unique or not

//insert the exam in exam list
$ins = "INSERT INTO exams(name,type,depart,inform,permission,code,verified,tyme,created_by) VALUES('$examname','$examtype','$depart','$permission','$for','$code', '$verified', '$time','$created_by')";
$insert = mysqli_query($con,$ins);
//check what type of exam will be created
if($examtype=="quiz")
{
  if($for=="public")
  {
    $cre = "CREATE TABLE pu_la_quiz_$examname(
           qno INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
           question VARCHAR(400) NOT NULL,
           op1 VARCHAR(100) NOT NULL,
           op2 VARCHAR(100) NOT NULL,
           op3 VARCHAR(100) NOT NULL,
           op4 VARCHAR(100) NOT NULL,
           ans VARCHAR(10) NOT NULL
           )";
    $create=mysqli_query($con,$cre);
    if($create)
    {
      header("location:enter_quiz_ques.php");
    }
    else
    {
      echo "<script> alert('Something went to wrong. Exam can't create); </script>";
    }
  }
  else if(($for=="private") || ($for=="both"))
  {
    $cre = "CREATE TABLE pr_la_quiz_$examname(
           qno INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
           question VARCHAR(400) NOT NULL,
           op1 VARCHAR(100) NOT NULL,
           op2 VARCHAR(100) NOT NULL,
           op3 VARCHAR(100) NOT NULL,
           op4 VARCHAR(100) NOT NULL,
           ans VARCHAR(10) NOT NULL
           )";
    $create=mysqli_query($con,$cre);
    if($create)
    {
      
      echo "<script>confirm('Do your want to set the time limit for this exam.');</script>";
      header("location:take_time.php");
    }
    else
    {
      echo "<script> alert('Something went to wrong. Exam can't create); </script>";
    }
  }
  else
  {
    echo "<script> alert('For what is not selected. Somethig went to wrong.');</script>";
  }
  
}
else if($examtype=="true")
{
	if($for=="public")
  {
    $cre = "CREATE TABLE pu_la_true_$examname(
           qno INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
           question VARCHAR(400) NOT NULL,
           true_false VARCHAR(10) NOT NULL
           )";
    $create=mysqli_query($con,$cre);
    if($create)
    {
      header("location:enter_true_ques.php");
    }
    else
    {
      echo "<script> alert('Something went to wrong. Exam can't create); </script>";
    }
  }
  else if(($for=="private") || ($for=="both"))
  {
    $cre = "CREATE TABLE pr_la_true_$examname(
           qno INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
           question VARCHAR(400) NOT NULL,
           true_false VARCHAR(10) NOT NULL
           )";
    $create=mysqli_query($con,$cre);
    if($create)
    {
      echo "<script>confirm('Do your want to set the time limit for this exam.');</script>";
      header("location:take_time.php");
    }
    else
    {
      echo "<script> alert('Something went to wrong. Exam can't create); </script>";
    }
  }
  else
  {
    echo "<script> alert('For what is not selected. Somethig went to wrong.');</script>";
  }
}
else if($examtype=="onew")
{
	if($for=="public")
  {
    $cre = "CREATE TABLE pu_la_onew_$examname(
           qno INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
           question VARCHAR(400) NOT NULL,
           ans VARCHAR(10) NOT NULL
           )";
    $create=mysqli_query($con,$cre);
    if($create)
    {
      header("location:enter_onew_ques.php");
    }
    else
    {
      echo "<script> alert('Something went to wrong. Exam can't create); </script>";
    }
  }
  else if(($for=="private") || ($for=="both"))
  {
    $cre = "CREATE TABLE pr_la_onew_$examname(
           qno INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
           question VARCHAR(400) NOT NULL,
           ans VARCHAR(10) NOT NULL
           )";
    $create=mysqli_query($con,$cre);
    if($create)
    {
      echo "<script>confirm('Do your want to set the time limit for this exam.');</script>";
      header("location:take_time.php");
    }
    else
    {
      echo "<script> alert('Something went to wrong. Exam can't create); </script>";
    }
  }
  else
  {
    echo "<script> alert('For what is not selected. Somethig went to wrong.');</script>";
  }
}

?>


