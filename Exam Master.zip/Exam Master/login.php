<!--Start page Reloading Validation-->
<?php
session_start();
if((isset($_SESSION['as_a'])) && ($_SESSION['as_a']=="admin"))
{
	header("location:admin_panel.php");
}
else
{
	
}
?>
<!--End Page Reloading Validation-->

<head>
	<?php include("header.php"); ?>
	<link rel="stylesheet" type="text/css" href="css/login.css">
</head>
<body class="bg-success">
	<div class="container">
		<div class="row">
			<div class="col-md-6"><div><img src="img/registration.png" class="imgs"></div></div>
			<div class="col-md-6 bg-danger" style="border: 1px dashed #F25119;margin-bottom: 20px;border-radius: 10px;">
				<h1 class="hs">L<span style="font-size: 23px;">ogin</span> H<span style="font-size: 23px;">ere</span></h1>
				<form action="login_action.php" method="POST" class="form">
					<div class="form-group">
						<label for="username">Username:</label>
						<input type="text" name="username" class="form-control" placeholder="Enter Your Username" required/>
					</div>
					<div class="form-group">
						<label for="password">Password:</label>
						<input type="password" name="pass" class="form-control" placeholder="Enter Your Password" required/>
					</div><?php if(isset($_GET['uu'])) echo "<script> alert('Something went to wrong. Make sure You are right person.');</script>";?>
					<div class="form-group">
						<label for="log in as">Log in as: </label>
						<select class="form-control" name="as_a">
							<option value="">--You Are--</option>
							<option value="admin">Admin</option>
							<option value="teacher">Teacher</option>
							<option value="student">Student</option>
						</select>
					</div>
					<input type="submit" name="btn" class="btn btn-primary btn-block btns" value="Login"><br>
					<p style="font-weight: 600;">I don't have any account <a href="signup.php" class="sup">Sign Up.</a></p>
				</form>
			</div>
		</div>
	</div>
</body>

<?php  include("footer.php"); ?>