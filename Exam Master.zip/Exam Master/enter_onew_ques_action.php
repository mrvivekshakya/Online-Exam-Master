<!--Start page Reloading Validation-->
<?php
session_start();
if((isset($_SESSION['as_a'])) && (($_SESSION['as_a']=="admin") || ($_SESSION['as_a']=="teacher")))
{
}
else
{
	header("location:index.php");
}
?>
<!--End Page Reloading Validation-->
<?php
include("connection.php");
if(isset($_POST["btn"]))
{
	$qs = $_POST["question"];
	$ans = $_POST["ans"];
	$set = $_POST["set"];

	//validation for only one word ans
	$blank = " ";
	$i = 0;
	$flag=0;
	while($ans[$i]!=NULL)
	{
		if($ans[$i] == " ")
		{
			$flag = 1;
		}
		$i++;
	}
	if($flag == 1)
	{
		header("location:enter_onew_ques.php?not=0");
	}
	else
	{
		//set for which
	    if($_SESSION["for"]=="public")
	    {
		    $for = "pu";
	    }
	    else if(($_SESSION["for"]=="private") || ($_SESSION["for"]=="both"))
	    {
		    $for = "pr";
	    }
	    else
	    {
	    	echo "<script> alert('Public or Private is not selected. Something went to worng.'); </script>";
	    }
	    //others
	    $depart = $_SESSION["depart"];
	    $type = $_SESSION['$examtype'];
	    $name = $_SESSION["examname"];
        //full exam name
        $exam = $for."_".$depart."_".$type."_".$name;
        $ins = "INSERT INTO $exam(question,ans) VALUES('$qs','$ans')";
        $insert = mysqli_query($con,$ins);
        if($insert)
        {
        	if($set==0)
    	    {
    		    header("location:enter_onew_ques.php");
    	    }
    	    else
    	    {
    		    if($_SESSION['depart']=="it")
    		{
    			header("location:exam_it.php?created=0");
    		}
    		else if($_SESSION['depart']=="gk")
    		{
    			header("location:exam_gk.php?created=0");
    		}
    		else if($_SESSION['depart']=="ma")
    		{
    			header("location:exam_ma.php?created=0");
    		}
    		else if($_SESSION['depart']=="ed")
    		{
    			header("location:exam_ed.php?created=0");
    		}
    		else if($_SESSION['depart']=="la")
    		{
    			header("location:exam_la.php?created=0");
    		}
    		else
    		{
    			echo "<script> alert('Dapartment is not matched. Something went to wrong.'); </script>";
    		}
    	    }
        }
        else
        {
    	    echo "<script> alert('Quesion is not inserted.Something went to wrong.');</script>";
        }
	}

}

?>