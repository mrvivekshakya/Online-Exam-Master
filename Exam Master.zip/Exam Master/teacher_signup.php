<?php
session_start();
if(isset($_SESSION["username"]))
{
	include("header1.php");
}
else
{
	include("header.php");
}
?>

<head>
	<link rel="stylesheet" type="text/css" href="css/teacher_signup.css">
	<style type="text/css">
		.form-control
		{
			border:1px solid gray;
		}
	</style>
</head>

<body class="bg-success">
	<div class="container bg-danger" style="border: 1px dashed #F25119;margin-bottom: 15px;">
		<h1 class="text-center" style="font-family: algerian;color: #0A585B;font-weight: 600;">T<span style="font-size: 25px;">eacher's</span> P<span style="font-size: 25px;">rofile</span> D<span style="font-size: 25px;">etail</span></h1>
		<form class="form-horizontal" action="teacher_signup_action.php" method="POST"  enctype="multipart/form-data">
			<div class="form-group">
				<label  class="control-label col-md-2" for="fname">Teacher's Name: </label>
				<div class="col-md-5">
					<input type="text" name="fname" placeholder=" First Name" class="form-control" required/>
				</div>
				<div class="col-md-5">
					<input type="text" name="sname" placeholder=" Second Name" class="form-control" required/>
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-md-2" for="username">Username: </label>
				<div class="col-md-4">
					<input type="text" name="username" placeholder="Username" class="form-control" required/><span><?php
					if(isset($_GET["u"])) echo "<font color='red'> Username is not matched.</font>"; ?></span>
				</div>
				<label class="control-label col-md-2" for="username">Email: </label>
				<div class="col-md-4">
					<input type="email" name="email" placeholder="Email Address" class="form-control" required/>
				</div>
			</div>
			<div class="form-group">
				<label  class="control-label col-md-2" for="mobile">Mobile: </label>
				<div class="col-md-1">
					<select name="code" class="form-control">
						<option value="+91">+91</option>
					</select>
				</div>
				<div class="col-md-4">
					<input type="number" name="mobile" placeholder="9027149894" class="form-control" required/>
				</div>
				<label  class="control-label col-md-1" for="phone">Phone: </label>
				<div class="col-md-4">
					<input type="text" name="phone" placeholder="23 545 45" class="form-control" required/>
				</div> 
			</div>
			<div class="form-group">
				<label class="control-label col-md-2" for="username">Address: </label>
				<div class="col-md-10">
					<input type="text" name="add1" placeholder="Address Line 1" class="form-control" required/>
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-md-2" for=""></label>
				<div class="col-md-10">
					<input type="text" name="add2" placeholder="Address Line 2" class="form-control" required/>
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-md-2" for="city">City: </label>
				<div class="col-md-4">
					<input type="text" name="city" placeholder="City" class="form-control" required/>
				</div>
				<label class="control-label col-md-2" for="state">State: </label>
				<div class="col-md-4">
					<input type="text" name="state" placeholder="State" class="form-control" required/>
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-md-2" for="portal">Zip Code/Portal: </label>
				<div class="col-md-4">
					<input type="number" name="portal" placeholder="205001" class="form-control" required/>
				</div>
				<label class="control-label col-md-2" for="country">Country: </label>
				<div class="col-md-4">
					<input type="text" name="country" placeholder="Country" class="form-control" required/>
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-md-2" for="DOB">Date of Birth: </label>
				<div class="col-md-4">
					<input type="date" name="dob" min="01-01-1990"  class="form-control" required/>
				</div>
				<label class="control-label col-md-2" for="gender">Gender: </label>
				<div class="col-md-4">
					<label class="radio-inline">
						<input type="radio" name="gender" value="male" required/>Male
					</label>
					<label class="radio-inline">
						<input type="radio" name="gender" value="female" required/>Female
					</label>
					<label class="radio-inline">
						<input type="radio" name="gender" value="other" required/>Other
					</label>
				</div>
			</div>
			<hr style="border:1px dashed #FFC78C;">
			<div class="form-group">
				<label class="control-label col-md-2" for="department">Department: </label>
				<div class="col-md-4">
					<select class="form-control" name="department">
						<option value="">--Select--</option>
						<option value="it">IT</option>
						<option value="management">Management</option>
						<option value="low">Low</option>
						<option value="education">Education</option>
					</select>
				</div>
				<label class="control-label col-md-2" for="experience">Experience: </label>
				<div class="col-md-4">
					<input type="number" name="experience" placeholder="2" class="form-control" required/>
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-md-2">Qualification: </label>
				<div class="col-md-10">
					<input type="text" name="qualification" placeholder="Qualification" class="form-control" required/>
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-md-2" for="image">Image: </label>
				<div class="col-md-3">
					<input type="file" name="image" required/>
				</div>
				<label class="control-label col-md-3" for="Marksheet">Higher Qualification Marksheet: </label>
				<div class="col-md-4">
					<input type="file" name="marksheet" required/>
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-md-2">You are: </label>
				<div class="col-md-4">
					<select class="form-control" name="you_are">
						<option value="">--Select--</option>
						<option value="primary school teacher">Primary School Teacher</option>
						<option value="junior school teacher">Junior School Teacher</option>
						<option value="senior school teacher">Senior School Teacher</option>
						<option value="assistant professor">Assistant Professor</option>
						<option value="professor">Professor</option>
					</select>
				</div>
				<label class="control-label col-md-2">Specification: </label>
				<div class="col-md-4">
					<input type="text" name="specification" placeholder="Specification" class="form-control" required/>
				</div>
			</div>
			<div class="form-group">
				<div style="margin-left: 5px;margin-right: 15px;"><label>What interests you about Sorority Registration? </label></div>
				<textarea placeholder="Enter something here..." style="margin-left: 15px;width: 97%;height: 20%;margin-right: 15px;" name="des"></textarea>
			</div>
			<div class="form-group text-center">
				<input type="submit" name="btn" value="Submit" class="btn btn-primary btn-lg">
				<input type="reset" name="reset" value="Clear" class="btn btn-warning btn-lg">
				<input type="submit" name="print" value="Print" class="btn btn-danger btn-lg" onclick="print()">
			</div>
		</form>
	</div>
</body>

<?php
include("footer.php");
?>