<!--Start page Reloading Validation-->
<?php
session_start();
if((isset($_SESSION['as_a'])) && (($_SESSION['as_a']=="admin") || ($_SESSION['as_a']=="admin")))
{
}
else
{
	header("location:index.php");
}
?>
<!--End Page Reloading Validation-->

<?php
include("connection.php");
if(isset($_POST["btn_time"]))
{
	$time = $_POST["time"];
	$name=$_SESSION["examname"];

	//update time of the exam in the table
	$upd = "UPDATE exams SET tyme='$time' WHERE name='$name'";
	$update = mysqli_query($con,$upd);
	if($update)
	{
		if($_SESSION['$examtype']=="quiz")
		{
			header("location:enter_quiz_ques.php");
		}
		else if($_SESSION['$examtype']=="true")
		{
			header("location:enter_true_ques.php");
		}
		else if($_SESSION['$examtype']=="onew")
		{
			header("location:enter_onew_ques.php");
		}		
		else
		{
			echo "<script> alert('Exam Type is not selected Something went to wrong.'); </script>";
		}
	} 
	else
	{
		echo "<script> alert('Something went to wrong.');</script>";
	}
}
?>
