<?php 
include("header.php");
?>
<div class="container">
	<form class="form">
		
		<div class="input-group">
			<span class="input-group-addon" style="border-radius: 0px;	">First Name:</span>
			<input type="text" name="fname" class="form-control bg-primary" placeholder="Enter Your First Name" style="border-radius: 0px;	">
		</div>
		<div class="input-group">
			<span class="input-group-addon" style="solid gray; border-top: 0px solid red;box-shadow: 0px 0px 0px;border-radius: 0px;		">First Name:</span>
			<input type="text" name="fname" class="form-control" placeholder="Enter Your First Name" style=" solid gray; border-top: 0px solid red;box-shadow: 0px 0px 0px;border-radius: 0px;	" >
		</div>
<br>
		<div class="input-group">
			<span class="input-group-addon">First Name:</span>
			<input type="text" name="fname" class="form-control" placeholder="Enter Your First Name">
		</div>
		<div class="input-group">
			<span class="input-group-addon" >First Name:</span>
			<input type="text" name="fname" class="form-control" placeholder="Enter Your First Name" >
		</div>

	</form>
	 <form class="form">
	 	<div class="input-group">
	 		<input type="text" name="fname" placeholder="Enter Your Name" class="form-control" style="color: red;">
	 		<div class="input-group-btn">
	 			<button class="btn btn-primary">Hii</button>
	 		</div>
	 	</div>
	 </form>
</div>
<?php
include("footer.php");
?>