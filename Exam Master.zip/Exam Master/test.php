<?php include("header1.php"); ?>
<!DOCTYPE html>

<body>
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-2 class="collapse navbar-collapse" id="myNavbar"">
				<div class="row">
					<div class="col-sm-12" style="background-color: #0A585B;">vivek</div>
					<div class="col-sm-12" style="background-color: #0A585B;">vivek</div>
					<div class="col-sm-12" style="background-color: #0A585B;">vivek</div>
					<div class="col-sm-12" style="background-color: #0A585B;">vivek</div>
				</div>
			</div>
			<div "col-sm-10">falktjaoeiuloiw</div>
		</div>
	</div>

</body>

<?php include("footer.php"); ?>