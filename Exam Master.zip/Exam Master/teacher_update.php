<!--Start page Reloading Validation-->
<?php
error_reporting(0);
session_start();
if((isset($_SESSION['as_a'])) && ($_SESSION['as_a']=="admin"))
{
}
else
{
	header("location:index.php");
}
?>
<!--End Page Reloading Validation-->


<?php include("header1.php"); ?>
<head>
	<link rel="stylesheet" type="text/css" href="css/admin_panel.css">
	<style type="text/css">
    .main
    {
        margin-top:-21px;
        z-index: 0;
    }   
        .an{
      text-decoration: none;
      color: #F25119;
    }
    .an:hover
    {
      text-decoration: none;
      color: #F25119;
      text-shadow: 1px 1px 2px white;
      background-color: #0C393D;
  }
    .buttonn
    {
        background-color: #0A585B;
        border: 0px inset #F25119;
        border-radius: 10px;
    }
    .active1
    {
        background-color: #0C393D;
    }
    .nav11
    {
        display: block;
    }
    .bars
    {
        
        font-size: 22px;
        padding: 10px;
        color: #F25119;
        display: none;
        margin-top: -66px;
        width: 30px;
        
    }
    .bars:hover{
      color: #F25119;
      text-shadow: 1px 1px 2px white;
    }
    @media screen and (max-width: 768px){
        .nav11
        {
            display: none;
            position: absolute;
            width: 400px;
            z-index: 10;
        }
        .bars
        {
            display: block;
            z-index: 10;
            position:sticky;
            top: 8;
            
        }
        .first_part{
            display: none;
            position:sticky;
            top: 8;
        }
    }

    
    </style>
    <script type="text/javascript">
        function show()
        {
            a=document.getElementById('nav11').style;
            if(a.display=="block")
            {
                a.display="none";
            }
            else
            {
                a.display="block";
            }
        }
        function validate()
        {
            p=document.getElementById("pass").value;
            rp=document.getElementById("rpass").value;
            if(p!=rp)
            {
                if(p=="")
                {
                    document.getElementById("msg").innerHTML="<h5><font color='red'>Firstly Create Your Password.</font></h5>";
                    return false;
                }
                else
                {
                    document.getElementById("msg").innerHTML="<h5><font color='red'>Password is not matched till now.</font></h5>";
                    return false;
                }
                
            }
            else
            {
                document.getElementById("msg").innerHTML="";
                return true;
            }   
        }
    </script>
</head>


<div class=" bars" id="bars" onclick="show()"><span class="fa fa-bars"></span></div>
<body class="bg-success">
    <div class="container-fluid main">
        <div class="row" >
            <div class="col-md-2 first_part nav11" style="padding: 0px;background-color:#0A585B;height: 90%;" id="nav11">
                
				<div class="btn-group-vertical btn-block" >
                    <a class="an btn btn-lg btn-block buttonn" href="admin_panel.php" style="text-shadow: 2px 2px 2px white;font-weight: 1000;">Admin Panel</a>
					<a class="an btn btn-lg btn-block buttonn" href="admin_profile.php"><span class="fa fa-user"></span> &nbsp;Profile</a>
					<a class="an btn btn-lg btn-block buttonn" href="activities.php">Activities</a>
					<a class="an btn btn-lg btn-block buttonn" href="teachers_list.php">Teacher's List</a>
					<a class="an btn btn-lg btn-block buttonn" href="students_list.php">Student's List</a>
					<a class="an btn btn-lg btn-block buttonn" href="exam_it.php" >Make a IT Exam</a>
					<a class="an btn btn-lg btn-block buttonn" href="exam_gk.php">Make a GK Exam</a>
					<a class="an btn btn-lg btn-block buttonn" href="exam_ma.php">Make a Mang. Exam</a>
					<a class="an btn btn-lg btn-block buttonn" href="exam_ed.php">Make a Education Exam</a>
					<a class="an btn btn-lg btn-block buttonn" href="exam_la.php">Make a Law Exam</a>
                    <a class="an btn btn-lg btn-block buttonn" href="schedule_exam.php">Schedule a Exam</a>
                    <a class="an btn btn-lg btn-block buttonn" href="change_admin_pass.php">Change Password</a>


				</div>
			</div>
			<div class="col-md-10" style="padding: 0px;">

            <!--php start for fectching all details of this teacher-->

            <?php

            include("connection.php");
            $id = $_GET['id'];
            $sel = "SELECT * FROM SIGNUP WHERE id='$id'";
            $select = mysqli_query($con,$sel);
            $teacher = mysqli_fetch_row($select);
            ?>

            <!--php end for fectching all details of this teacher-->
            <!--When current password didn't match-->
            <?php

            $id1 = $_GET['id1'];
            $username=$_GET['username'];
            $email=$_GET['email'];
            if(isset($_GET['username']))
                echo "<script> document.getElementById('not').innerhtml = 'hello javascript';</script>";
            ?>
            <!------------ -->

				<div class="container-fluid ">
                <h1 class="hs text-center">Update Details</h1>
                <form class="form-horizontal" action="teacher_update_action.php" method="POST" onsubmit="return validate()">
                    <div class="form-group">
                        <label class="control-label col-md-2">User Id: </label>
                        <div class="col-md-10">
                            <input type="text" name="id" placeholder="" class="form-control" value="<?php echo "$teacher[0]"."$id1"; ?>" title="User Id Cann't be change in any case" readonly/>
                            
                        </div>
                    </div><br/>
                    <div class="form-group">
                        <label class="control-label col-md-2">Username: </label>
                        <div class="col-md-10">
                            <input type="text" name="username" placeholder="Create a Username" class="form-control" value="<?php echo "$teacher[1]"."$username"; ?>" autofocus required/>
                            <span><?php if(isset($_GET["u"])) echo "<font color='red'>Username is already exist try another</font>";?></span>
                        </div>
                    </div><br/>
                    <div class="form-group">
                        <label class="control-label col-md-2">Email: </label>
                        <div class="col-md-10">
                            <input type="email" name="email" placeholder="Enter Your Email Address" class="form-control" value="<?php echo "$teacher[2]"."$email"; ?>" autofocus required/>
                        </div>
                    </div><br/>
                    <div class="form-group">
                        <label class="control-label col-md-2">Current Password: </label>
                        <div class="col-md-10">
                            <input type="password" name="cpass" id="cpass" placeholder="Enter Your Current Password" class="form-control" autofocus required/>
                        </div><div id="not"></div>
                    </div><br/>
                    <div class="form-group">
                        <label class="control-label col-md-2">Create Password: </label>
                        <div class="col-md-10">
                            <input type="password" name="pass" id="pass" placeholder="Create a Password" class="form-control" autofocus required/>
                        </div>
                    </div><br/>
                    <div class="form-group">
                        <label class="control-label col-md-2" >Re-enter Password:  </label>
                        <div class="col-md-10" >
                            <input type="password" name="rpass" id="rpass" placeholder="Confirm Password" class="form-control" oninput="" autofocus required/>
                            <span id="msg"></span>
                        </div>
                    </div><?php //if(isset($_GET["t"])) echo "Sorry ur Password not Matched...."; ?><br>

                    <div class="form-group">
                        <label class="control-label col-md-2" ></label>
                        <div class="col-md-10" >
                            <button class="btn btn-primary btn-lg btns" name="btn" value="update">Update</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button class="btn btn-primary btn-lg btns" name="btn" value="update_more">Update more...</button>
                        </div>
                        
                    </div><br>
                </form>
            </div>
			</div>

		</div>
	</div>
</body>
<?php if(isset($_GET['already'])) echo "<script> alert('This Username is already exist.\\nTry Another One.'); </script>"; ?>
<?php if(isset($_GET['cur'])) echo "<script> alert('The Current Password does not match.\\nTry Again.'); </script>"; ?>

<?php include("footer.php"); ?>

