<?php
include("connection.php");

if(isset($_POST["btn"]))
{
	$username = $_POST["username"];
	$pass = $_POST["pass"];
	$as_a = $_POST["as_a"];

	//Fetch the data 
	$sel="SELECT * FROM SIGNUP ORDER BY 1";
    $select=mysqli_query($con,$sel);
    $rows=mysqli_num_rows($select);
    $flag=0;
    while($rows!=0)
    {
        while($data=mysqli_fetch_assoc($select))
        {
            if(($username==$data['username']) && ($pass==$data['pass']) && ($as_a==$data['as_a']))
            {
                $flag=1;
            }
        }
        $rows--;
    }
    if($flag==1)
    {
    	include("connection.php");
    	$ins = "INSERT INTO LOGIN(username,password,as_a) values('$username','$pass','$as_a')";
    	$insert = mysqli_query($con,$ins);
    	if($insert)
    	{
    		if($as_a=="admin")
    		{
    			 header("location:admin_panel.php");
    		}
    		else if($as_a=="teacher")
    		{
    			 header("location:teacher_panel.php");
    		}
    		else if($as_a=="student")
    		{
    			 header("location:student_panel.php");
    		}
    		else
    		{
    			 header("location:login.php");
    		}
                session_start();
                $_SESSION["username"]=$username;
                $_SESSION["pass"]=$pass;
                $_SESSION["as_a"]=$as_a;
    	}
    	else
    	{
    		echo "something wrong..in insertion.";
    	}
    }
    else
    {
    	header("location:login.php?uu=0");
    }
}
?>