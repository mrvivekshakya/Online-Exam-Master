<?php
include("connection.php");
if(isset($_POST["btn"]))
{
    $username=$_POST["username"];
    $email=$_POST["email"];
    $pass=$_POST["pass"];
    $rpass=$_POST["rpass"];
    $as_a=$_POST["as_a"];

    //factch username
    $sel="SELECT * FROM SIGNUP ORDER BY 1";
    $select=mysqli_query($con,$sel);
    $rows=mysqli_num_rows($select);
    $flag=1;

    while($rows!=0)
    {
    	while($data=mysqli_fetch_assoc($select))
    	{
    		if($username==$data['username'])
    		{
    			
    			header("location:signup.php?u=0");
    			$flag=0;

    		}
        $rows--;
        }
    }

    if($flag==1)
    {
    	if(($pass==$rpass) && ($as_a!=""))
	    {
		    $ins="INSERT INTO SIGNUP(username,email,pass,as_a) values('$username','$email','$pass','$as_a')";
		    $insert=mysqli_query($con,$ins);
		    if($insert)
		    {
			    if($as_a=="teacher")
			    {
				    echo "<script> confirm('Something went to wrong.'); </script>";
				    header("location:teacher_signup.php");
			    }
			    else if($as_a=="student")
			    {
				    echo "<script> confirm('Something went to wrong.'); </script>";
				    header("location:student_signup.php");
			    }
			    else if($as_a=="other")
			    {
				    echo "other";
			    }
			    else
			    {
				    echo "as_a not selected";
			    }
		    }
		    else
		    {
			    echo "<script> alert('Something went to wrong.'); </script>";
		    }
	    }
	    else
	    {
		    header("location:signup.php");
	    }
    }
    else if($flag==0)
    {
    	header("location:signup.php?already=0");
    }
    else
    {
    	echo "<script> alert('Something Went to Wrong.'); </scrript>";
    }
}
?>