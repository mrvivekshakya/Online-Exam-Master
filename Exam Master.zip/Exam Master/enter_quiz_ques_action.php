<!--Start page Reloading Validation-->
<?php
session_start();
if((isset($_SESSION['as_a'])) && (($_SESSION['as_a']=="admin") || ($_SESSION['as_a']=="teacher")))
{
}
else
{
	header("location:index.php");
}
?>
<!--End Page Reloading Validation-->
<?php
include("connection.php");
if(isset($_POST["btn"]))
{
	$qs = $_POST["question"];
	$op1 = $_POST["op1"];
	$op2 = $_POST["op2"];
	$op3 = $_POST["op3"];
	$op4 = $_POST["op4"];
	$ans = $_POST["ans"];
	$set = $_POST["set"];

	//set for which
	if($_SESSION["for"]=="public")
	{
		$for = "pu";
	}
	else if(($_SESSION["for"]=="private") || ($_SESSION["for"]=="both"))
	{
		$for = "pr";
	}
	else
	{
		echo "<script> alert('Public or Private is not selected. Something went to worng.'); </script>";
	}
	//others
	$depart = $_SESSION["depart"];
	$type = $_SESSION['$examtype'];
	$name = $_SESSION["examname"];
    //full exam name
    $exam = $for."_".$depart."_".$type."_".$name;
    echo $exam;

    $ins = "INSERT INTO $exam(question,op1,op2,op3,op4,ans) VALUES('$qs','$op1','$op2','$op3','$op4','$ans')";
    $insert = mysqli_query($con,$ins);
    if($insert)
    {
    	if($set==0)
    	{
    		header("location:enter_quiz_ques.php");
    	}
    	else
    	{
    		if($_SESSION['depart']=="it")
    		{
    			header("location:exam_it.php?created=0");
    		}
    		else if($_SESSION['depart']=="gk")
    		{
    			header("location:exam_gk.php?created=0");
    		}
    		else if($_SESSION['depart']=="ma")
    		{
    			header("location:exam_ma.php?created=0");
    		}
    		else if($_SESSION['depart']=="ed")
    		{
    			header("location:exam_ed.php?created=0");
    		}
    		else if($_SESSION['depart']=="la")
    		{
    			header("location:exam_la.php?created=0");
    		}
    		else
    		{
    			echo "<script> alert('Dapartment is not matched. Something went to wrong.'); </script>";
    		}	
    	}
    }
    else
    {
    	echo "<script> alert('Quesion is not inserted.Something went to wrong.');</script>";
    }


}

?>