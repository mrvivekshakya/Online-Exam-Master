<?php
$con=mysqli_connect("localhost","root","","exammaster");
if(!$con)
{
	echo "Database is not connected because: ".mysqli_connect_error();
}
?>