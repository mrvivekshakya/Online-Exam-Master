<?php
include("connection.php");
if(isset($_POST["btn"]))
{
    $fname = $_POST["fname"];
    $sname = $_POST["sname"];
    $username = $_POST["username"];
    $email = $_POST["email"];
    $code = $_POST["code"];
    $mobile = $_POST["mobile"];
    $phone = $_POST["phone"];
    $add1 = $_POST["add1"];
    $add2 = $_POST["add2"];
    $city = $_POST["city"];
    $state = $_POST["state"];
    $portal = $_POST["portal"];
    $country = $_POST["country"];
    $dob = $_POST["dob"];
    $gender = $_POST["gender"];
    $department = $_POST["department"];
    $experience = $_POST["experience"];
    $qualification = $_POST["qualification"]; 
    
    //for image
    $image = $_FILES["image"]["tmp_name"];
    $rimage = $_FILES["image"]["name"];
    $folder= "uploads/teachers/".$rimage;
    //for marksheet
    $marksheet = $_FILES["marksheet"]["tmp_name"];
    $rmarksheet = $_FILES["marksheet"]["name"];
    $folder1= "uploads/marksheets/".$marksheet;
    
    $you_are = $_POST["you_are"];
    $specification = $_POST["specification"];
    $des = $_POST["des"];

    //fatch existing username
    $sel="SELECT * FROM SIGNUP ORDER BY 1";
    $select=mysqli_query($con,$sel);
    $rows=mysqli_num_rows($select);
    $flag=0;
    while($rows!=0)
    {
        while($data=mysqli_fetch_assoc($select))
        {
            if($username==$data['username'])
            {
                $flag=1;
            }
        }
        $rows--;
    }
    if($flag==1)
    {
        $ins = "INSERT INTO TEACHER_SIGNUP(fname,sname,username,email,code,mobile,phone,address1,address2,city,state,portal,country,dob,gender,department,experience,qualification,image,marksheet,you_are,specification,description) values('$fname','$sname','$username','$email','$code','$mobile','$phone','$add1','$add2','$city','$state','$portal','$country','$dob','$gender','$department','$experience','$qualification','$rimage','$rmarksheet','$you_are','$specification','$des')";
        $insert = mysqli_query($con,$ins);
        if($insert)
        {
            move_uploaded_file($marksheet, $folder1);
            move_uploaded_file($image, $folder);
            echo "done";
            header("location:login.php");
        }
        else
        {
                    echo "Something went to wrong."; 
        }
    }
    if($flag==0)
    {
        header("location:teacher_signup.php?u=0");
    }
}
?>